﻿namespace NETMCUCore.STM
{
    public enum GPIO_Pull : uint
    {
        NoPull = 0x00000000,
        Up = 0x00000001,
        Down = 0x00000002
    }
}
