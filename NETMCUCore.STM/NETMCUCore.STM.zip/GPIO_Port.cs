﻿namespace NETMCUCore.STM
{
    public enum GPIO_Port : uint
    {
        PortA = 0,
        PortB = 1,
        PortC = 2,
        PortD = 3,
        PortE = 4,
        PortF = 5,
        PortG = 6,
        PortH = 7,
        PortI = 8,
        PortJ = 9,
        PortK = 10
    }
}
