﻿namespace NETMCUCore.STM
{
    public enum GPIO_Speed : uint
    {
        Low = 0x00000000,
        Medium = 0x00000001,
        High = 0x00000002,
        VeryHigh = 0x00000003
    }
}
